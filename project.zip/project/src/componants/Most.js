import React from 'react'

export default function Most() {
  return (
    <div>Most Viewed Product</div>
  )
}
