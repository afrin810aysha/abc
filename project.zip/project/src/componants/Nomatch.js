import React from 'react'

export default function Nomatch() {
  return (
    <div>Page not found</div>
  )
}
