import React from 'react'

export default function New() {
  return (
    <div>New Products</div>
  )
}
